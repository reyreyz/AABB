Numbers section (Moussa & Kahl).
main.tex              standalone document; compile with pdfLaTeX (Overleaf default)
numerics_section.tex  the section itself; \input{numerics_section} into the paper
Packages: amsmath, amssymb, booktabs, graphicx, algorithm, algpseudocode, lmodern (all in TeX Live / Overleaf).
